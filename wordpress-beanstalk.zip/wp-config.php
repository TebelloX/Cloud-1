<?php
define('DB_NAME', 'ebdb');
define('DB_USER', 'master');
define('DB_PASSWORD', 'Tsholofelo1');
define('DB_HOST', 'http://cloud-1.ccoy7ffryrx3.us-east-1.rds.amazonaws.com/' . ':' . '3306');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');
define('AUTH_KEY',    'MMt(_Ren|zH#m,B.yR/cQ,/lDUpVSnv<1HLr8&Mm%WjY$`Z*/e8/g_:D$S64-H|B');
define('SECURE_AUTH_KEY',  'e!W6ceOM R~Q{-8gMZ`,BSK|y3BqcUF5`hNR}N}c,ODu6*N0I$IRpZ:Ea62svBoi');
define('LOGGED_IN_KEY',    'y8$,. V<&lteNEyQ$b*!gHT+hy+[T3K$L|FT(w>aTCA98~8>wG-GZu7<iZw3:*:|');
define('NONCE_KEY',     'tMS7bj3h[ &-HK~Z-;M{S[!w`#]+u.7W_Q!wpD|@:0S>v.-y)]1{A*?u|(d|]Rj');
define('AUTH_SALT', '3B+J8s8.hOT21i51??W17<6|*,~3z-s^$I5L#4N+6*@76ctd[xlTFm6m{k3Eqj3]');
define('SECURE_AUTH_SALT', 'h|-V.~JLu$N?kWbbDwKCY<n3]l?`|3iG+2B^RD@:7<hv&R<oJ-tm;:<yx5e;|4=-');
define('LOGGED_IN_SALT',   '=hoUs^.gIte}c%:E,e24mA:5sljKL7d`{YaE!mhC$^AW8mK!rn5K9P|-dFcJdT(/');
define('NONCE_SALT',       'n;,gx%hz@9 a&nibj]x2N6Wlw8^-R=+/(ezUd*3Gk+-$:02-Wz)-aX,40foFM+9Y');
$table_prefix  = 'wp_';
define('WP_DEBUG', false);
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');
